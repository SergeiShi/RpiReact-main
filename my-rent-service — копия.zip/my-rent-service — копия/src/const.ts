const Setting ={
    rentalOffersCount: 312,
} as const;

export {Setting};